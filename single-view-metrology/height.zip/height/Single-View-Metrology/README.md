# Single-View-Metrology
3D construction of an object from its 2D image using 3 point perspective. The homography and the projection matrices are calculated and are used to apply affine transformations to the image to obtain texture maps.
